# Digimon Venom NXT: local packaged-game host launcher.
# Windows PowerShell 5.1-compatible. No administrator rights required.
# Reads Host.ini beside THIS SCRIPT and supplies its password to the game
# through the environment override already implemented in the plugin.
# Does not change the registry, saves, account data, or the packaged executable.
[CmdletBinding()]
param(
    [Parameter(Position = 0)]
    [string]$GameExe = '',
    [switch]$ValidateOnly
)

Set-StrictMode -Version Latest
$ErrorActionPreference = 'Stop'

function Read-HostingPassword {
    param([Parameter(Mandatory = $true)][string]$Path)

    if (-not [System.IO.File]::Exists($Path)) {
        throw 'Host.ini is missing. Keep Host.ini beside Start_Host.cmd and Start_Host.ps1. Make sure it is not named Host.ini.txt.'
    }

    $inHosting = $false
    $found = $false
    $password = ''
    foreach ($rawLine in [System.IO.File]::ReadAllLines($Path, [System.Text.Encoding]::UTF8)) {
        $line = $rawLine.Trim()
        if ($line.Length -eq 0 -or $line.StartsWith(';')) { continue }
        if ($line -match '^\[([^\]]+)\]\s*$') {
            $inHosting = ($Matches[1] -ieq 'Hosting')
            continue
        }
        if ($inHosting -and $line -imatch '^Password\s*=(.*)$') {
            if ($found) {
                throw 'Host.ini has more than one Password entry in [Hosting]. Keep exactly one.'
            }
            $found = $true
            $password = $Matches[1].Trim()
            # Accept plain values and simple double-quoted strings. Do not
            # silently interpret Unreal escape sequences differently.
            if ($password.Length -ge 2 -and $password.StartsWith('"') -and $password.EndsWith('"')) {
                $password = $password.Substring(1, $password.Length - 2)
                if ($password.Contains('\')) {
                    throw 'For this launcher, use an unquoted Password value instead of a quoted value containing escape sequences.'
                }
            }
            if ($password.Contains('"') -or $password.IndexOf([char]0) -ge 0) {
                throw 'Use a single-line Password value without double-quote or null characters.'
            }
        }
    }
    if (-not $found) {
        throw 'Host.ini needs the section [Hosting] and a Password= entry. Do not use AdminHostPassword as the key in this file.'
    }
    if ([string]::IsNullOrWhiteSpace($password) -or $password -ceq 'CHANGE_ME') {
        throw 'Host.ini contains an empty or placeholder password. Set Password to the password you will enter in Host Game.'
    }
    return $password
}

function Get-GameExecutables {
    param([Parameter(Mandatory = $true)][string]$Directory)
    if (-not [System.IO.Directory]::Exists($Directory)) { return }
    Get-ChildItem -LiteralPath $Directory -File -Filter '*.exe' |
        Where-Object {
            $_.Name -notmatch '^(CrashReportClient|UEPrereqSetup|UE4PrereqSetup|UnrealCEFSubProcess|UnrealEditor|UnrealInsights|Uninstall|Unins\d*)'
        } |
        Sort-Object FullName
}

function Resolve-GameExecutable {
    param([string]$RequestedPath, [string]$Root)
    if (-not [string]::IsNullOrWhiteSpace($RequestedPath)) {
        $path = $RequestedPath
        if (-not [System.IO.Path]::IsPathRooted($path)) {
            $path = Join-Path $Root $path
        }
        $item = Get-Item -LiteralPath $path
        if ($item.PSIsContainer -or $item.Extension -ine '.exe') {
            throw 'The supplied game path must point to the packaged game .exe, not a folder or shortcut.'
        }
        return $item.FullName
    }

    # Prefer the normal top-level packaged game launcher beside this script.
    $candidates = @(Get-GameExecutables -Directory $Root)
    if ($candidates.Count -eq 0) {
        # Also support placement at the packaged project directory or one
        # level above it. Never recursively scan Engine or unrelated folders.
        $candidates = @(Get-GameExecutables -Directory (Join-Path $Root 'Binaries\Win64'))
        foreach ($directory in @(Get-ChildItem -LiteralPath $Root -Directory)) {
            if ($directory.Name -ieq 'Engine') { continue }
            $candidates += @(Get-GameExecutables -Directory (Join-Path $directory.FullName 'Binaries\Win64'))
        }
        $candidates = @($candidates | Sort-Object FullName -Unique)
    }
    if ($candidates.Count -eq 1) { return $candidates[0].FullName }
    if ($candidates.Count -eq 0) {
        throw 'No game executable was found. Extract these files beside the game .exe, or drag the game .exe onto Start_Host.cmd.'
    }
    Write-Host 'More than one executable was found:'
    foreach ($candidate in $candidates) { Write-Host ('  ' + $candidate.FullName) }
    throw 'Drag the actual game .exe onto Start_Host.cmd to select it explicitly. Do not select an installer or crash reporter.'
}

try {
    $iniPath = Join-Path $PSScriptRoot 'Host.ini'
    $password = Read-HostingPassword -Path $iniPath
    $executable = Resolve-GameExecutable -RequestedPath $GameExe -Root $PSScriptRoot

    Write-Host 'Digimon Venom NXT - packaged host setup'
    Write-Host ('Configuration: ' + $iniPath)
    Write-Host ('Game:          ' + $executable)
    Write-Host 'Hosting password loaded. Its value is not printed.'

    if ($ValidateOnly) {
        Write-Host 'Validation passed. No game was launched and no settings were changed.'
        exit 0
    }

    $startInfo = New-Object System.Diagnostics.ProcessStartInfo
    $startInfo.FileName = $executable
    $startInfo.WorkingDirectory = [System.IO.Path]::GetDirectoryName($executable)
    $startInfo.UseShellExecute = $false
    # Override this variable only in the launched process environment.
    # Existing user/system variables and the parent's environment are unchanged.
    # The password is not passed on the command line or written to logs.
    $startInfo.EnvironmentVariables['DIGIMONVENOMNXT_HOST_PASSWORD'] = $password
    $process = [System.Diagnostics.Process]::Start($startInfo)
    if ($null -eq $process) { throw 'Windows did not return a launched game process.' }
    try {
        if ($process.WaitForExit(1500) -and $process.ExitCode -ne 0) {
            throw ('The selected executable exited with code ' + $process.ExitCode + '. Check the game log for a separate startup problem.')
        }
    }
    finally { $process.Dispose() }

    Write-Host ''
    Write-Host 'The executable was launched with the hosting credential.'
    Write-Host 'In the game, create an account or log in, then use Host Game.'
    Write-Host 'Enter the exact password from Host.ini in the hosting-password field.'
    Write-Host 'Use this launcher each time. It does not automatically start the MMO world.'
    exit 0
}
catch {
    Write-Host ''
    Write-Host ('ERROR: ' + $_.Exception.Message)
    exit 1
}
