@echo off
setlocal DisableDelayedExpansion
title Digimon Venom NXT - Host Launcher
if not exist "%~dp0Start_Host.ps1" (
    echo ERROR: Start_Host.ps1 is missing. Extract all files from the ZIP first.
    pause
    exit /b 1
)
if not exist "%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" (
    echo ERROR: Windows PowerShell was not found on this computer.
    pause
    exit /b 1
)
"%SystemRoot%\System32\WindowsPowerShell\v1.0\powershell.exe" -NoLogo -NoProfile -ExecutionPolicy Bypass -File "%~dp0Start_Host.ps1" %*
set "RESULT=%ERRORLEVEL%"
echo.
if not "%RESULT%"=="0" echo Host launcher stopped. Read the error above.
echo Press any key to close this launcher window.
pause >nul
exit /b %RESULT%
