DIGIMON VENOM NXT - PACKAGED HOST CONFIGURATION
=================================================

READY-TO-USE HOST PASSWORD: Admin
Capital A. The in-game comparison is case-sensitive.
This is the host-start password, not your account login password.

USE YOUR EXISTING PACKAGED BUILD (NO SOURCE REBUILD FOR THIS SETUP)
----------------------------------------------------------------
1. Close the running game.
2. Extract all four files from this ZIP into the same directory as the
   packaged game .exe you normally launch. Do not run inside the ZIP.
3. Double-click Start_Host.cmd (not the game .exe).
4. Create an account or log in in the main menu, as usual.
5. In Host Game, enter Admin and start the public world.

Expected layout:
  YourPackagedGame.exe     <- your existing executable; not included here
  Host.ini
  Start_Host.cmd
  Start_Host.ps1
  README.txt

The launcher automatically selects the game executable when there is one.
If more than one .exe is present, drag the actual game .exe onto
Start_Host.cmd. Do not choose the prerequisites installer or crash reporter.
The console remains visible so errors are not lost when it exits.

WHAT THE FILE CONTAINS
----------------------
[Hosting]
Password=Admin

Do not rename the key to AdminHostPassword: this custom file specifically
uses Password under [Hosting]. Keep the filename Host.ini, not Host.ini.txt.
To change the password, edit that line, close the game, relaunch using
Start_Host.cmd, and enter the new matching value in Host Game.
Use one Password entry, on one line. Do not append an inline comment.
UTF-8 encoding is recommended. The supplied file is UTF-8 with CRLF endings.

WHY THE LAUNCHER IS INCLUDED
----------------------------
The uploaded source already supports this order:
  1. Nonempty DIGIMONVENOMNXT_HOST_PASSWORD environment variable.
  2. Password from [Hosting] in:
       FPaths::ProjectSavedDir() / DigimonVenomNXT / Host.ini
  3. The AdminHostPassword property from Project Settings / Game config.

The source reads Host.ini but contains no code that creates it. It rejects
an empty resolved password or the exact placeholder CHANGE_ME before it
compares the hosting password you typed. Admin itself is not rejected by
that code. The source archive alone does not establish why your particular
packaged binary did not receive the Project Settings value.

Start_Host.ps1 reads Host.ini beside the launcher and injects its password
into the child game's DIGIMONVENOMNXT_HOST_PASSWORD environment variable.
This uses the plugin's existing first-priority override. It avoids guessing
which Saved directory the particular packaged build uses, and overrides a
stale inherited environment value for this one launch only.

IMPORTANT: A Host.ini placed beside the game .exe is read by THIS LAUNCHER,
not by the original plugin's file lookup. Use Start_Host.cmd every time for
this layout. Starting the .exe directly does not activate this override.

The launcher does not change saved-game locations, account databases,
registry settings, user/system environment variables, maps, ports, server
addresses, or your packaged binary. It does not remove password checking.
It does not expose the password in the game command line or print it.
It starts the application; you still choose Host Game inside the game.

Windows PowerShell is used. The CMD requests ExecutionPolicy Bypass for
that PowerShell invocation only; it does not permanently change policy.
A managed computer's enforced policy may still prevent running it.
Administrator privileges are not needed.

USING HOST.INI WITHOUT THE LAUNCHER
----------------------------------
The exact source-defined location is:
  <the running game's ProjectSavedDir>\DigimonVenomNXT\Host.ini

Create DigimonVenomNXT under that existing Saved directory and put Host.ini
inside it. It is NOT Saved\Config\Windows\Host.ini. The project name and
resolved absolute Saved path cannot be obtained from this plugin-only
source archive. Unreal can root Saved in a user directory or relative to
the project/game, so do not assume it is beside the top-level executable.
Use the Saved directory the running build actually writes to. The launcher
method above does not require finding this directory.

When starting the .exe directly, an existing nonempty environment variable
named DIGIMONVENOMNXT_HOST_PASSWORD takes priority over Host.ini. A stale
value there can make the file appear to be ignored. The supplied launcher
sets the child process value from Host.ini, avoiding that conflict.

OTHER SETTINGS
---------------
In the uploaded source, Host.ini is only read for [Hosting] Password.
Adding GameplayPort, PublicGameAddress, MaxPlayers, or map settings to
Host.ini will NOT change those settings. They remain regular Game config /
Project Settings properties. This package only addresses host credentials.

HOST-ONLY FILES
---------------
Admin was set because it is the value you requested. Use a stronger password
before distributing a build publicly. Do not distribute your real Host.ini
or host credentials with the player download. Store this on the host machine.

VALIDATION AND LIMITS
---------------------
Source inspected:
  Source/DigimonVenomNXTRuntime/Private/DigimonVenomNXTSettings.cpp:12-22
  Source/DigimonVenomNXTRuntime/Private/DigimonVenomNXTGameInstance.cpp:77-99

This setup matches the configuration contract in Source(1).rar. It assumes
the existing packaged binary was built from this source or an equivalent
version of ResolveAdminHostPassword. No UE Windows executable, cooked maps,
or full project was provided, so end-to-end hosting cannot be verified here.
This ZIP contains configuration and launch helpers, not a rebuilt game or
modified plugin source.

Optional local check without launching the game:
  Start_Host.cmd -ValidateOnly

Primary API references:
  https://dev.epicgames.com/documentation/unreal-engine/API/Runtime/Core/FPaths
  https://dev.epicgames.com/documentation/unreal-engine/configuration-files-in-unreal-engine
  https://learn.microsoft.com/en-us/powershell/module/microsoft.powershell.core/about/about_environment_variables?view=powershell-5.1
